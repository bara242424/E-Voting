Requirements :
click==8.1.7
colorama==0.4.6
dlib==19.24.4
face-recognition==1.3.0
face_recognition_models==0.3.0
numpy==1.26.4
opencv-python==4.9.0.80
pillow==10.3.0
setuptools==70.0.0
